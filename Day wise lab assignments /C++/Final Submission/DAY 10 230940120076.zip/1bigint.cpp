// Assignment: 

// 1. In BigInt class overload following operators:
//    Binary operators + - * / to work with
//    - both operands of type BigInt
//    - one BigInt operand and one int
//    Unary operators ++ and -- in both pre and post form.
//    Also write a small program to demonstrate the use of BigInt class and overloaded operators.


#include <iostream>
#include <string>
using namespace std;

class BigInt {
private:
    int value;

public:
    BigInt() : value(0) {}
    BigInt(int val) : value(val) {}
    BigInt operator+(const BigInt& other) const {
        return BigInt(value + other.value);
    }
    BigInt operator-(const BigInt& other) const {
        return BigInt(value - other.value);
    }
    BigInt operator*(const BigInt& other) const {
        return BigInt(value * other.value);
    }
    BigInt operator/(const BigInt& other) const {
        if (other.value == 0) {
            std::cerr << "Error: Division by zero." << std::endl;
            return BigInt();
        }
        return BigInt(value / other.value);
    }
    BigInt operator++() {
        ++value;
        return *this;
    }
    BigInt operator++(int) {
        BigInt temp(*this);
        ++value;
        return temp;
    }
    BigInt operator--() {
        --value;
        return *this;
    }
    BigInt operator--(int) {
        BigInt temp(*this);
        --value;
        return temp;
    }
    void display() const {
        cout << "Value: " << value << endl;
    }
};

int main() {
    BigInt a(50);
    BigInt b(5);

    BigInt sum = a + b;
    BigInt difference = a - b;
    BigInt product = a * b;
    BigInt quotient = a / b;

    cout << "a: ";
    a.display();
    cout << "b: ";
    b.display();
    cout << "a + b: ";
    sum.display();
    cout << "a - b: ";
    difference.display();
    cout << "a * b: ";
    product.display();
    cout << "a / b: ";
    quotient.display();

    BigInt x(7);
    cout << "x: ";
    x.display();
    cout << "Increment x (pre-increment): ";
    (++x).display();
    cout << "x after pre-increment: ";
    x.display();

    BigInt y(8);
    cout << "y: ";
    y.display();
    cout << "Increment y (post-increment): ";
    (y++).display();
    cout << "y after post-increment: ";
    y.display();

    BigInt z(12);
    cout << "z: ";
    z.display();
    cout << "Decrement z (pre-decrement): ";
    (--z).display();
    std::cout << "z after pre-decrement: ";
    z.display();

    BigInt w(15);
    cout << "w: ";
    w.display();
    cout << "Decrement w (post-decrement): ";
    (w--).display();
    cout << "w after post-decrement: ";
    w.display();

    return 0;
}
