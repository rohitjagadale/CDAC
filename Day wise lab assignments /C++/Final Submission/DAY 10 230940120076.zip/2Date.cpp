// 2. For the Date class overload following operators.
//    Binary operator + to work with
//    - one Date operand and one int
//    Binary operator - to work with
//    - both operands of type Date
//    - one Date operand and one int
//    Unary operators ++ and -- in both pre and post form.
//    Also write a small program to demonstrate the use of Date class and overloaded relational operators.


#include <iostream>
using namespace std;
class Date {
    int day;
    int month;
    int year;
public:
    Date();
    Date(int d, int m, int y) : day(d), month(m), year(y) {}
    void Read() {
        cout << "Enter day: ";
        cin >> this->day;
        cin >> this->month;
        cin >> this->year;
    };
    void Write() {
        cout << this->day << " ";
        cout << this->month << " ";
        cout << this->year << " \n ";
    };
    void operator+(int i) {
        this->day = this->day + i;
    }
    void operator-(int i) {
        this->day = this->day - i;
    }
    void operator-(Date d2) {
        this->day = this->day - d2.day;
        this->month = this->month - d2.month;
        this->year = this->year - d2.year;
    }
    bool operator==(Date obj2) {
        return (this->day == obj2.day && this->month == obj2.month && this->year == obj2.year);
    }
    Date operator++() {
        this->day++;
        return *this;
    }
    Date operator++(int) {
        Date temp = *this;
        ++this->day;
        return temp;
    }
    Date operator--() {
        this->day--;
        return *this;
    }
    Date operator--(int) {
        Date temp = *this;
        --this->day;
        return temp;
    }
    bool operator<(Date obj2) {
        if (this->year < obj2.year) return true;
        if (this->year == obj2.year && this->month < obj2.month) return true;
        if (this->year == obj2.year && this->month == obj2.month && this->day < obj2.day) return true;
        return false;
    }
    bool operator>(Date obj2) {
        if (this->year > obj2.year) return true;
        if (this->year == obj2.year && this->month > obj2.month) return true;
        if (this->year == obj2.year && this->month == obj2.month && this->day > obj2.day) return true;
        return false;
    }
    bool operator<=(Date obj2) {
        return !(*this > obj2);
    }
    bool operator>=(Date obj2) {
        return !(*this < obj2);
    }
    bool operator!=(Date obj2) {
        return !(*this == obj2);
    }
};
int main() {
    Date d1(24, 11, 1);
    Date d2(25, 1, 23);
    
    cout << "Initial d1: ";
    d1.Write();
    d1 + 5;
    cout << "After adding 5 days to d1: ";
    d1.Write();
    d1 - 5;
    cout << "After subtracting 5 days from d1: ";
    d1.Write();
    d1 - d2;
    cout << "Subtracting d2 from d1: ";
    d1.Write();
    ++d1;
    cout << "After pre-incrementing d1: ";
    d1.Write();
    d1++;
    cout << "After post-incrementing d1: ";
    d1.Write();
    --d1;
    cout << "After pre-decrementing d1: ";
    d1.Write();
    d1--;
    cout << "After post-decrementing d1: ";
    d1.Write();
    cout << "Comparison results:\n";
    cout << "d1 == d2: " << (d1 == d2) << endl;
    cout << "d1 != d2: " << (d1 != d2) << endl;
    cout << "d1 < d2: " << (d1 < d2) << endl;
    cout << "d1 > d2: " << (d1 > d2) << endl;
    cout << "d1 <= d2: " << (d1 <= d2) << endl;
    cout << "d1 >= d2: " << (d1 >= d2) << endl;

    return 0;
}
