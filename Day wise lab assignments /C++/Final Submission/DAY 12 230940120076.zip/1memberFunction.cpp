
// Assignment: 

// For String, Date and Array classes do following:
// - Identify member functions that should be made constant member function and convert them to constant member functions.
// - Identify where all objects should be passed by reference and make the changes.
//   Also, make changes at appropriate places, to pass them as reference to constant objects.

#include <iostream>
#include <cstring>
using namespace std;

class String {
private:
    char* data;
    int length;

public:
    String(const char* str) {
        length = strlen(str);
        data = new char[length + 1];
        strcpy(data, str);
    }

    int getLength() const {
        return length;
    }
    char getCharAt(int index) const {
        if (index >= 0 && index < length) {
            return data[index];
        }
        return '\0'; 
    }

    ~String() {
        delete[] data;
    }
};

class Date {
private:
    int day;
    int month;
    int year;

public:
    Date(int d, int m, int y) : day(d), month(m), year(y) {}

    int getDay() const {
        return day;
    }

    int getMonth() const {
        return month;
    }

    int getYear() const {
        return year;
    }
};

template <typename T>
class Array {
private:
    T* elements;
    int size;

public:
    Array(int sz) : size(sz) {
        elements = new T[size];
    }
    T& operator[](int index) {
        if (index >= 0 && index < size) {
            return elements[index];
        }
        static T dummy;
        return dummy;
    }
    const T& operator[](int index) const {
        if (index >= 0 && index < size) {
            return elements[index];
        }
        static T dummy;
        return dummy;
    }

    ~Array() {
        delete[] elements;
    }
};

int main() {
    String str("Rohit, Jagadale");
    Date today(19, 9, 2023);
    Array<int> arr(5);

    cout << "String length: " << str.getLength() << endl;
    cout << "Date: " << today.getDay() << "/" << today.getMonth() << "/" << today.getYear() << std::endl;

    for (int i = 0; i < 5; ++i) {
        arr[i] = i * 2;
    }

    for (int i = 0; i < 5; ++i) {
        cout << "arr[" << i << "] = " << arr[i] << endl;
    }

    return 0;
}
