﻿namespace Day3Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee[] arrEmps = new Employee[5];


            for (int i = 0; i < arrEmps.Length; i++)
            {
                arrEmps[i] = new Employee();
                arrEmps[i].Name = Console.WriteLine("Enter The Name :"+Console.ReadLine());
                arrEmps[i].Basic= Convert.ToDecimal(Console.ReadLine());
          
                arrEmps[i].DeptNo = Convert.ToInt16(Console.ReadLine());
                //arrEmps[i].EmpNo
            }


           
            for (int i = 0; i < arrEmps.Length; i++)
            {
                //item = new Employee();  //will not work -- item is readonly
                Console.WriteLine(arrEmps[i]);
                //will work
            }


        }
    }

    public class Employee
    {
        public static int empCounter = 1;
        private string name;
        private int empNo;
        private decimal basic;
        private short deptNo;


        public decimal GetNetSalary()
        {
            return basic + 10000;
        }


        public Employee(string name = "abc", decimal basic = 0, short deptNo = 1)
        {
            empNo = empCounter;
            empCounter++;
            
            this.Name = name;
            this.Basic = basic;
            this.DeptNo = deptNo;
            this.Basic = GetNetSalary();
        }



        public int EmpNo
        {
            get { return empNo; }


        }

        public String Name
        {
            get { return name; }
            set
            {
                bool b1 = String.IsNullOrEmpty(value);


                if (b1 == true)
                {

                    Console.WriteLine("Invalid Name");
                }
                else
                {
                    name = value;
                }
            }
        }

        public decimal Basic
        {
            get { return basic; }
            set
            {
                if (value >= 0 && value < 50000)
                {
                    basic = value;

                }
                else
                {
                    System.Console.WriteLine("Invalid Basic Salary Please" +
                        " add salary between 10000 and 50000");
                }


            }
        }


        public short DeptNo
        {
            get { return deptNo; }
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    System.Console.WriteLine("Invalid Department Number Please add above 0)");
                }


            }
        }





    }
}







