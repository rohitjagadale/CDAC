﻿namespace Day3Assignment
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee[] arrEmps = new Employee[2];


            for (int i = 0; i < arrEmps.Length; i++)
            {
                arrEmps[i] = new Employee();
                Console.WriteLine("Enter Name: ");
                arrEmps[i].Name = Console.ReadLine();
                Console.WriteLine("Enter Basic Salary: ");
                arrEmps[i].Basic= (Convert.ToDecimal(Console.ReadLine()));
                Console.WriteLine("Enter Department No : ");
                arrEmps[i].DeptNo = Convert.ToInt16(Console.ReadLine());
                //arrEmps[i].EmpNo
            }


           
            for (int i = 0; i < arrEmps.Length; i++)
            {
                //item = new Employee();  //will not work -- item is readonly
                Console.WriteLine("Name Of Employee :"+arrEmps[i].Name);
                Console.WriteLine("NO Of Employee :" + arrEmps[i].EmpNo);
                Console.WriteLine("Basic Of Employee :" + arrEmps[i].Basic);
                Console.WriteLine("Name Of Deprtment No :" + arrEmps[i].DeptNo);
                //will work
            }


        }
    }

    public class Employee
    {
        public static int empCounter = 1;
        private string name;
        private int empNo;
        private decimal basic;
        private short deptNo;


        public decimal GetNetSalary()
        {
            return basic + 10000;
        }


        public Employee(string name = "abc", decimal basic = 10001, short deptNo = 1)
        {
            empNo = empCounter;
            empCounter++;
            
            this.Name = name;
            this.Basic = basic;
            this.DeptNo = deptNo;
            this.Basic = basic;
        }



        public int EmpNo
        {
            get { return empNo; }


        }

        public String Name
        {
            get { return name; }
            set
            {
                bool b1 = String.IsNullOrEmpty(value);


                if (b1 == true)
                {

                    Console.WriteLine("Invalid Name");
                }
                else
                {
                    name = value;
                }
            }
        }

        public decimal Basic
        {
            get { return basic; }
            set
            {
                if (value >= 10000 && value < 50000)
                {
                    basic = value;

                }
                else
                {
                    System.Console.WriteLine("Invalid Basic Salary Please" +
                        " add salary between 10000 and 50000");
                }


            }
        }


        public short DeptNo
        {
            get { return deptNo; }
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    System.Console.WriteLine("Invalid Department Number Please add above 0)");
                }


            }
        }





    }
}







