﻿namespace StaticMembers
{
    internal class Program
    {
        static void Main(string[] args)
        {
           Class1 class1 = new Class1();
           Class1.s_Display();

            class1.Prop1 = 8;
        }
    }


    public class Class1
    {
        public int i;
        public static int s_i=101;

        public void Display()
        {
            Console.WriteLine("Dis");
            Console.WriteLine(i);
            Console.WriteLine(s_i);
        }


        public static void s_Display()
        {
            //we canot access non static member in static 
           // Console.WriteLine(i);
            Console.WriteLine(s_i);
        }

        private int prop1;

        public int Prop1
        {
            set { 
            if (value>10) {
                    Console.WriteLine("Invalid value");


                }
                else
                {
                    prop1=value;
                    System.Console.WriteLine(prop1);
                }
            
            
            }

            get { return prop1; }
               
        }
    
    }
}