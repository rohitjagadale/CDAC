﻿namespace Functions
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            //postional parameters
            Class2 class2 = new Class2();
            Console.WriteLine(class2.Add2(10, 20, 30));
            Console.WriteLine(class2.Add2(10, 20));
            Console.WriteLine(class2.Add2(10));



            //named parameters

            Console.WriteLine(class2.Add2(b:10,a:30));
            Console.WriteLine(class2.Add2(c:20));

            //local varialbles and local functions
            Class3 class3 = new Class3();
            class3.Dosomething();





        }


        


    }




    public class Class2
    {
        public void Display()
        {
            Console.WriteLine("Display");
        }

        public int Add2(int a = 0, int b = 0, int c = 0)
        {
            return a + b + c;

        }
    }



    public class Class3
    {
        int i = 100;
        public void Dosomething()
        {
            i++;
            Console.WriteLine(i);
        }
    }












}