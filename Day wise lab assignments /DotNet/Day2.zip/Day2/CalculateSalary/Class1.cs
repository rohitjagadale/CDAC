﻿namespace CalculateSalary
{
    public class calcSal
    {
        public decimal calSalary(decimal basic)
        {
            return basic+100001;
        }
    }
}