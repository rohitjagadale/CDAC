﻿using CalculateSalary;
using System.Runtime.CompilerServices;
using System.Xml.Linq;


namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");

            Employee o1 = new Employee();
            Employee o2 = new Employee();
            Employee o3 = new Employee();
            Console.WriteLine(o1.EmpNo);
            Console.WriteLine(o2.EmpNo);
            Console.WriteLine(o3.EmpNo);

            Console.WriteLine(o3.EmpNo);
            Console.WriteLine(o2.EmpNo);
            Console.WriteLine(o1.EmpNo);
        }
    }


    public class Employee
    {
        public static int empCounter = 1;
        private string name;
        private int empNo;
        private decimal basic;
        private short deptNo;






        public decimal GetNetSalary()
        {
            return basic + 10000;
        }
        

        int newSalary;

        public Employee(string name = "abc", decimal basic = 0, short deptNo = 1)
        {
            empNo = empCounter;
            empCounter++;
            calcSal c = new calcSal();
            this.Name = name;
            this.Basic = basic;
            this.DeptNo = deptNo;
            c.calSalary(Basic); 
        }





        public int EmpNo
        {
            get { return empNo; }


        }

        public String Name
        {
            get { return name; }
            set
            {
                bool b1 = String.IsNullOrEmpty(value);


                if (b1 == true)
                {

                    Console.WriteLine("Invalid Name");
                }
                else
                {
                    name = value;
                }
            }
        }

        public decimal Basic
        {
            get { return basic; }
            set
            {
                if (value >= 0 && value < 50000)
                {
                    basic = value;

                }
                else
                {
                    System.Console.WriteLine("Invalid Basic Salary Please" +
                        " add salary between 10000 and 50000");
                }


            }
        }


        public short DeptNo
        {
            get { return deptNo; }
            set
            {
                if (value > 0)
                {
                    deptNo = value;
                }
                else
                {
                    System.Console.WriteLine("Invalid Department Number Please add above 0)");
                }


            }
        }




















    }






}







