package com.app.service;

import java.util.List;

import com.app.pojos.Student;

public interface CourseService {
	// add a method to get abbreviations of all teams
	List<String> getAllCourseAbbreviations();

	List<Student> getStudentsEnrolledByCourseName(String courseName);
}
