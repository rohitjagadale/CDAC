package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Student;

@Repository
public class StudentDaoImpl implements StudentDao {
	@Autowired
	private EntityManager manager;

	@Override
	public List<Student> getAllStudent() {

			String jpql="select s from Student s";// e join fetch e.myDept";
			return manager
					.createQuery(jpql, Student.class)
					.getResultList();
		}
	
}
