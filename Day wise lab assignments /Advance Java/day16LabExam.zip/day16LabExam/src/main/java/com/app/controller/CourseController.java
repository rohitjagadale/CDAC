package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.pojos.Student;
import com.app.service.CourseService;

@Controller
@RequestMapping("/teams")
public class CourseController {
	@Autowired
	private CourseService courseService;

	public CourseController() {
		System.out.println("in ctor of " + getClass());
	}

	// add req handling method to get all teams abbreviations
	@GetMapping("/abbrs")
	public String getAllCourseAbbreviations(Model map, Student newStudent) {
		//SC : map.addAttribute("player",new Player());  MOdel --> View 
		System.out.println("in get all course abbr " + map);//{player : playerpojo}
		map.addAttribute("courses_abbr", courseService.getAllCourseAbbreviations());
		System.out.println("map again "+map);//populated with 2 entries 
		return "/courses/add_student_form";// AVN : /WEB-INF/views/teams/add_player_form.jsp
		
	}
		
	    @PostMapping("/studentsEnrolled")
	    public String getStudentsEnrolled(@RequestParam String courseName, Model map) {
	        // Validate courseName (you might want to add more validation)
	        if (courseName == null || courseName.isEmpty()) {
	            // Handle invalid input, e.g., redirect to an error page
	            return "redirect:/error";
	        }

	        // Call the service to get students enrolled in the specified course
	        // Assuming you have a method like getStudentsEnrolledByCourseName in your CourseService
	        // Implement this method in your CourseService
	        List<Student> enrolledStudents = courseService.getStudentsEnrolledByCourseName(courseName);

	        // Add the enrolled students to the model for displaying in the view
	        map.addAttribute("enrolledStudents", enrolledStudents);

	        return "/courses/enrolled_students";
	}
}
