package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.app.pojos.Course;

@Repository
public class CourseDaoImpl implements CourseDao {
	//dep : EntitiyManager (super i/f of Hibernate Session)
	@Autowired
	private EntityManager manager;

	@Override
	public List<String> getAllCourseAbbreviations() {
		String jpql="select c.abbreviation from Course c";
		return manager.createQuery(jpql, String.class)
				.getResultList();
	}

	@Override
	public Course getCourseDetailsByAbbreviation(String abbr1) {
		String jpql="select c from Course c where c.abbreviation=:abbr";
		return manager.createQuery(jpql, Course.class)
				.setParameter("abbr", abbr1)
				.getSingleResult();
	}
	

}
