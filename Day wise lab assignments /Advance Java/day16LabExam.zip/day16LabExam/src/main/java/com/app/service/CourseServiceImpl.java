package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CourseDao;
import com.app.pojos.Student;

@Service
@Transactional
public class CourseServiceImpl implements CourseService {
	@Autowired
	private CourseDao courseDao;

	@Override
	public List<String> getAllCourseAbbreviations() {
		// TODO Auto-generated method stub
		return courseDao.getAllCourseAbbreviations();
	}
	// CourseServiceImpl class

	// Existing methods...

	@Override
	public List<Student> getStudentsEnrolledByCourseName(String courseName) {
	    // Implement the logic to retrieve students enrolled in the specified course
	    // You might need to query the database or fetch from a data store
	    // For simplicity, let's assume there's a method in your CourseDao for this purpose
	    return courseDao.getStudentsEnrolledByCourseName(courseName);
	}


}
