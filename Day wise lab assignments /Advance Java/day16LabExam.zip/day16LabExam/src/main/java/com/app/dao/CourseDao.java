package com.app.dao;

import java.util.List;

import com.app.pojos.Course;
import com.app.pojos.Student;

public interface CourseDao {
//add a method to get abbreviations of all teams
	List<String> getAllCourseAbbreviations();
	//get team's details from the abbr.
	Course getCourseDetailsByAbbreviation(String abbr);
	List<Student> getStudentsEnrolledByCourseName(String courseName);
	
}
