package com.app.service;

import java.util.List;

import com.app.pojos.Student;

public interface StudentService {
	String addStudentToCourse(Student newStudent, String abbreviation);
	List<Student> listStudent();
}
