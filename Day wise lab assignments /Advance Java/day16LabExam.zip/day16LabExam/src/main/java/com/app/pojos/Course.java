package com.app.pojos;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.*;

//id , name, abbreviation,owner,max_age,batting_avg,wickets_taken
//one , parent, inverse
@Entity
@Table(name = "course")
public class Course extends BaseEntity {
	@Column(length = 100)
	private String name;
	@Column(length = 10)
	private String abbreviation;
	@Column(length = 20)
	
	// add the asso property
	// Team 1--->* Player
	@OneToMany(mappedBy = "myCourse", 
			cascade = CascadeType.ALL, orphanRemoval = true)
	private List<Student> students = new ArrayList<>();

	public Course() {
		// TODO Auto-generated constructor stub
	}

	public Course(String name, String abbreviation, List<Student> students) {
		super();
		this.name = name;
		this.abbreviation = abbreviation;
		this.students = students;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAbbreviation() {
		return abbreviation;
	}

	public void setAbbreviation(String abbreviation) {
		this.abbreviation = abbreviation;
	}

	public List<Student> getStudents() {
		return students;
	}

	public void setStudents(List<Student> students) {
		this.students = students;
	}
	
	
	
	// add helper method to establish a bi dir link between Team n player
		public void addStudent(Student s) {
			students.add(s);
			s.setMyCourse(this);
		}

		// add helper method to un-establish a bi dir link between Team n player
		public void removeStuden(Student s) {
			students.remove(s);
			s.setMyCourse(null);
		}

	@Override
	public String toString() {
		return "Course [name=" + name + ", abbreviation=" + abbreviation + ", students=" + students + "]";
	}

	

}
