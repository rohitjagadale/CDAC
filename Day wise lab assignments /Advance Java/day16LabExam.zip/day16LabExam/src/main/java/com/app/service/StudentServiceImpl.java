package com.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.dao.CourseDao;
import com.app.dao.StudentDao;
import com.app.pojos.Course;
import com.app.pojos.Student;

@Service
@Transactional
public class StudentServiceImpl implements StudentService {
	/*
	 * Did NOT use it here , since using a cascading here
	 * 
	 * @Autowired private PlayerDao playerDao;
	 */
	@Autowired
	private CourseDao  courseDao;
	@Autowired
	private StudentDao studentDao;

	@Override
	public String addStudentToCourse(Student newStudent, String abbreviation) {
		// validate player details from the team's requirements
		// get team details from the abbreviation
		Course selectedCourse = courseDao.getCourseDetailsByAbbreviation(abbreviation);
		// validate
//		int age = Period.between(newPlayer.getDob(), LocalDate.now()).getYears();
//		if (age > selectedTeam.getMaxAge() || newPlayer.getBattingAvg() < selectedTeam.getBattingAvg()
//				|| newPlayer.getWicketsTaken() < selectedTeam.getWicketsTaken())
//			throw new RuntimeException("Invalid Player Details ...Please retry");
		// selectedTeam : persistent
		// simply set bi dir asso between Team n Player
		selectedCourse.addStudent(newStudent);
		return "Added Student to the Course";
	}// no exc ---session.flush -- auto dirty chking -- auto inserts player : cascade
		// !--commit

	@Override
	public List<Student> listStudent() {
		// TODO Auto-generated method stub
		List<Student> students = studentDao.getAllStudent();
//		students.forEach(e -> e.getCity());
		return students;
	}

}
