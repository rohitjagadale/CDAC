package com.app.pojos;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

/*
 * 	id (PK), first_name,last_name, dob,batting_avg,wickets_taken....
	+team_id (FK)
 */
@Entity
@Table(name = "student")
public class Student extends BaseEntity {
	@Column(length = 20, name = "first_name")
	private String firstName="abc";
	@Column(length = 20, name = "last_name")
	private String lastName="xyz";
	@Column(length = 20, name = "city")
	private String city="pune";
	
	
	
	//many , child , owning
	//Player *---->1 Team
	@ManyToOne
	@JoinColumn(name="course_id",nullable=false)
	private Course myCourse;
	

	public Student() {
		// TODO Auto-generated constructor stub
	}


	public Student(String firstName, String lastName, String city, Course myCourse) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.city = city;
		this.myCourse = myCourse;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city = city;
	}


	public Course getMyCourse() {
		return myCourse;
	}


	public void setMyCourse(Course myCourse) {
		this.myCourse = myCourse;
	}


	@Override
	public String toString() {
		return "Student [" +getRollNo() +"firstName=" + firstName + ", lastName=" + lastName + ", city=" + city + ", myCourse="
				+ myCourse + ", getRollNo()=" +  "]";
	}
	


}
