package customException;

public class IPLException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IPLException(String errMsg) {
		super(errMsg);
	}

}
