package beans;

import java.time.LocalDate;
import java.util.List;

import javax.persistence.Column;

import dao.PlayerDaoImpl;
import dao.TeamDaoImpl;
import pojos.Player;

public class PlayerBean {
	private TeamDaoImpl teamDao;
	private PlayerDaoImpl playerDao;// dependency
	private Player playerDetails;// result
	
	private String teamAbbr;
	private String firstName;
	private String lastName;
	private String dob;
	private double battingAvg;
	private int wicketsTaken;
	
	public PlayerBean() {
		playerDao = new PlayerDaoImpl();
		teamDao = new TeamDaoImpl();
		System.out.println("Player Bean created.....");
	}

	public PlayerDaoImpl getPlayerDao() {
		return playerDao;
	}

	public void setPlayerDao(PlayerDaoImpl playerDao) {
		this.playerDao = playerDao;
	}

	public Player getPlayerDetails() {
		return playerDetails;
	}

	public void setPlayerDetails(Player playerDetails) {
		this.playerDetails = playerDetails;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getDob() {
		return dob;
	}

	public TeamDaoImpl getTeamDao() {
		return teamDao;
	}

	public void setTeamDao(TeamDaoImpl teamDao) {
		this.teamDao = teamDao;
	}

	public String getTeamAbbr() {
		return teamAbbr;
	}

	public void setTeamAbbr(String teamAbbr) {
		this.teamAbbr = teamAbbr;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public double getBattingAvg() {
		return battingAvg;
	}

	public void setBattingAvg(double battingAvg) {
		this.battingAvg = battingAvg;
	}

	public int getWicketsTaken() {
		return wicketsTaken;
	}

	public void setWicketsTaken(int wicketsTaken) {
		this.wicketsTaken = wicketsTaken;
	}
	
	public List<String> showTeamAbbr(){
		List<String> teamAbbrs;
		teamAbbrs = teamDao.getTeamsAbbreviations();
		return teamAbbrs;
	}
	
	public String addPlayer() {
		//String firstName, String lastName, LocalDate dateOfBirth, double battingAverage, Integer wicketsTaken
		Player p = new Player(firstName, lastName, LocalDate.parse(dob), battingAvg, wicketsTaken);
		String mesg ;//= "Player could not be added!!";
		
		
		mesg = playerDao.addPlayerDetails(teamAbbr, p);
		
		return mesg;
	} 
}
