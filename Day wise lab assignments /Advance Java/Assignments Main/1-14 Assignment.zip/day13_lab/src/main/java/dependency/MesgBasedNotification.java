package dependency;

public class MesgBasedNotification implements CustomerNotificationService{

	public MesgBasedNotification() {
		System.out.println("in cnstr of " +getClass().getName());
	}
	@Override
	public void alertCustomer(String mesg) {
		System.out.println("Alerttt!!! " + mesg +" using message ");
		
	}

}
