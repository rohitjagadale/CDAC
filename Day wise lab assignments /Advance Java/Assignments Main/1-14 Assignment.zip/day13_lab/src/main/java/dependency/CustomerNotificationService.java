package dependency;

public interface CustomerNotificationService {
	public void alertCustomer(String mesg);
}
