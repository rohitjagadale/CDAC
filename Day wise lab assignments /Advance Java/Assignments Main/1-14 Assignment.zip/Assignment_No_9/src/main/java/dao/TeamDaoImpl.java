package dao;


import org.hibernate.*;


import pojos.Team;

import static utils.HibernateUtils.getFactory;

import java.util.List;

public class TeamDaoImpl implements TeamDao {

	@Override
	public String addTeamDetails(Team newTeam) {
		// 1. open hibernate session from SF
		Session session = getFactory().getCurrentSession();
		// 2. begin a tx
		Transaction tx = session.beginTransaction();
		try {
			session.save(newTeam);
			//end of try => success
			tx.commit();
		} catch (RuntimeException e) {
			// rollback tx n re throw the exc to the caller
			if (tx != null)
				tx.rollback();
			throw e;
		}
		return "Added new Team with ID "+newTeam.getTeamId();
	}
	
	
	@Override
	public List<Team> getTeamDetails(String abbreviation) {
		List<Team> teams = null;
		String jpql = " select t from Team t where t.abbreviation=:abr"; 
		
		Session session = getFactory().getCurrentSession();
		
		Transaction tx  = session.beginTransaction();
		try {
			teams = session.createQuery(jpql, Team.class).setParameter("abr", abbreviation).getResultList();
			tx.commit();
		}catch (Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
			// TODO: handle exception
		}
		return teams;
	}
	
	@Override
	public List<Team> getTeamsByMaxAge(int age) {
		List<Team> teams = null;
		String jpql = " select t from Team t where t.maxAge >= :age"; 
		
		Session session = getFactory().getCurrentSession();
		
		Transaction tx  = session.beginTransaction();
		try {
			teams = session.createQuery(jpql, Team.class).setParameter("age", age).getResultList();
			tx.commit();
		}catch (Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
			// TODO: handle exception
		}
		return teams;
	}

	@Override
	public String updateWicketsBattingAvg(Integer id,double batAvg, int wkts) {
		
		Team team = null;
		String mesg = "Team's batting average and wickets taken updation is failed";
		Session session = getFactory().getCurrentSession();
		
		Transaction tx  = session.beginTransaction();
		try {
			if(id!=null) {
				team = session.get(Team.class, id);
				team.setMinBattingAvg(batAvg);
				team.setMinWicketsTaken(wkts);
				tx.commit();
				 mesg = "Team's batting average and wickets taken is successfully upated";
			}
			else 
				throw new RuntimeException("Invalid Id");
				}catch (Exception e) {
			if(tx!=null)
				tx.rollback();
			throw e;
			// TODO: handle exception
		}
		return mesg;
	}


	


	

}
