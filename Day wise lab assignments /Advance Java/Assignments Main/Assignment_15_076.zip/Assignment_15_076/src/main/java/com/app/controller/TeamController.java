package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.app.service.TeamService;

@Controller

public class TeamController {
	@Autowired
	private TeamService teamService;
	public TeamController() {
		System.out.println("in constructor of"+getClass());
	}
	@GetMapping("/")
	public String  getTeamsAbbreviations(Model map) {
	map.addAttribute("teams_abbr",teamService.getTeamsAbbreviations());
	return "/teams/add_player_form";
}
}
