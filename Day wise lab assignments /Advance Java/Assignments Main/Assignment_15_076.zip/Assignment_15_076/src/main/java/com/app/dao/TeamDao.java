package com.app.dao;

import java.util.List;

public interface TeamDao {
List<String> getTeamsAbbreviations();
}
