package com.app.dao;

import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class Teamlmpl implements TeamDao {
	@Autowired
	private EntityManager manager;
	@Override


	public List<String> getTeamsAbbreviations() {
		// TODO Auto-generated method stub
		
		String jpql="select t.abbreviation from Team t";
		
		
		return manager.createQuery(jpql,String.class).getResultList();
		
		
	}

}
