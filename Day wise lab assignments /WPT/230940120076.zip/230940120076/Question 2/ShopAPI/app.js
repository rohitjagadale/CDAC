const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
const port = 3000;

app.use(cors());

// In-memory array to store products
const product = [];

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware to log requests
app.use((req, res, next) => {
  console.log(`${req.method} ${req.url}`);
  next();
});

// POST endpoint to save Products details
app.post("/new", (req, res) => {
  const { productId, productName, price, Date } = req.body;



  // Create a new Product object
  const newProduct = {
    productId, productName, price, Date
  };

  // Save the new Product to the in-memory array
  product.push(newProduct);

  // Return the newly added Product in the response
  res.status(201).json(newProduct);
});

// GET endpoint to retrieve all Product
app.get("/list", (req, res) => {
  res.json(product);
});



// Simple HTML form to interact with the API
app.get("/new", (req, res) => {
  res.send(`
        <form method="post" action="/new">
        <label for="productId">Product ID:</label>
        <input type="number" name="productId" required><br><br>
        <label for="productName">Product Name:</label>
        <input type="text" name="productName" required><br><br>
        <label for="Date"> Exipiry Date</label>
        <input type="Date" name="Date" required><br><br>
        <label for="price">Price:</label>
        <input type="number" name="price" required><br><br>
        <button type="submit">Add Product</button>
        </form>
    `);
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
