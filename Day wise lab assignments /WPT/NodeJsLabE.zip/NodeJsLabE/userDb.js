exports.users = [{username:"user123", password:"user"},
                {username:"test234", password:"test"},
                {username:"test123",password:"test"}
                ]