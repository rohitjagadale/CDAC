export default function AddEvent() {
    const [task, setTask] = useState([{ event_title: "", description: "", due_date: ""}]);
    const add = () => {
      let etitle = document.getElementById("title").value;
      let des = document.getElementById("desc").value;
      let dudate = document.getElementById("desc").value;
      if (etitle !== "") {
        setTask([...task, {event_title: etitle, description: des, due_date: dudate }]);
      }
    };
  
    return (
      <div>
        Event Management
        <form>
          Enter event_title:
          <input name="task" id="title" />
          Enter Description:
          <input name="duration" id="desc" />
          Enter date:
          <input name="duration" id="date" />
          <button name="add" id="add" type="button" onClick={add}>
            Add Task
          </button>
        </form>
        <div>
          <table>
            <thead>
              <td>Event</td>
              <td>Description</td>
              <td>due date</td>
            </thead>
            <tbody>
              {task.map((e) => (
                <tr key={e.event_title}>
                  <td>{e.event_title}</td>
                  <td>{e.description}</td>
                  <td>{e.due_date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    );
  }
  