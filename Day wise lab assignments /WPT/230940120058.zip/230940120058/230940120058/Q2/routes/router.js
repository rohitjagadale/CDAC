const express = require("express");
const app = express();
var router = express.Router();
let bodyParser = require("body-parser");
const eventServices = require("../services/eventservices");

router.get("/events", function (req, res) {
  var arr = empServices.getAllEvents();
  res.send(arr);
});
router.post("/events/:id", function (req, res) {
  eventServices.insertEvent(res.body);  
  res.send("data added successfully");
});
module.exports = router;
