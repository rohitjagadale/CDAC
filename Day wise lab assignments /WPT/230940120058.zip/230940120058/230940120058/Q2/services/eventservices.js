class Event {
    constructor() {
      this.eventarray = [
        {id:1, Event_Title : "Event1" , Description : "this is event1"},
        {id:2 ,Event_Title : "Event2" , Description : "this is event1"},
        {id:3 , Event_Title : "Event3" , Description : "this is event1" },
      ];
    }
    getAllEvents() {
      return this.eventarray;
    }

    insertEvent(ev) {
      this.eventarray.push(ev);
    }

  }
  module.exports = new Employee();
  