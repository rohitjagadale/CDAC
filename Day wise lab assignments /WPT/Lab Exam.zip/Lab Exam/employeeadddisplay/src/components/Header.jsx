const Header=()=>{
    return(
        <h1 style={{background:"black",color:"white",padding:"20px",borderRadius:"8px",textAlign:"center"}}>Employee Manegment System</h1>
    );
}

export default Header;