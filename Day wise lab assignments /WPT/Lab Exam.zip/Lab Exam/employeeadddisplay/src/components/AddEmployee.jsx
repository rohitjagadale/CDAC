import { Component } from 'react';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';

class AddEmployee extends Component{
constructor(props){
  super();
  this.state={
    id:"",
    name:"",
    salary:0

  }
}
 
addingEmployee=(event)=>{
  event.preventDefault();
  if (this.state.id === "" || this.state.name === "" || this.state.salary === "") {
    alert("All fields are mandatory");
    return;
  }
  
  this.props.AddEmployeeHandler(this.state)
  this.setState({id:"",name:"",salary:""});
}

render(){
    return(
<div class="container">
 <div class="row justify-content-center">
 
<Form >
<h1>Add Employee</h1>
      <Form.Group className="mb-3" controlId="formBasicId">
        <Form.Label>Employee ID</Form.Label>
        <Form.Control type="number" placeholder="Enter ID" 
        value={this.state.id}
        onChange={(event)=>this.setState({id:event.target.value})}
        />
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicName">
        <Form.Label>Name</Form.Label>
        <Form.Control type="text" placeholder="name" 
         value={this.state.name}
         onChange={(event)=>this.setState({name:event.target.value})}/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicSalary">
        <Form.Label>Salary</Form.Label>
        <Form.Control type="number" placeholder="Salary" 
         value={this.state.salary}
         onChange={(event)=>this.setState({salary:event.target.value})}/>
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group>
      <Button variant="primary" type="submit" onClick={(this.addingEmployee)}>
        Submit
      </Button>
    </Form>

    </div>
    <hr /></div>
    );
}}

export default AddEmployee;