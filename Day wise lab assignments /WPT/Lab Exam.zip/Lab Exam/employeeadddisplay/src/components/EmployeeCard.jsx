const EmployeeCard=(props)=>{
    return(
        <div className="container">
            <div className="row align-items-center justify-content-center">
           
                <h5><span>{props.Employee.id} </span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span> {props.Employee.name}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span> {props.Employee.salary}</span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                </h5>
            </div>
            
        </div>
    );
}

export default EmployeeCard;