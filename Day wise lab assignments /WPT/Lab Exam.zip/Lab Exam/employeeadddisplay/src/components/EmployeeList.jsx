import EmployeeCard from "./EmployeeCard"

const EmployeeList=(props)=>{
   const renderEmployeeByTable=()=>{
    return(
        props.Employee.map((emps,index)=><tr key={index}>
            <td>{emps.id}</td>
            <td>{emps.name}</td>
            <td>{emps.salary}</td>
        </tr>))
    }
    const renderEmployeeByComponent=()=>
       
            props.Employee.map((emps,index)=>{return(<EmployeeCard Employee={emps} key={index}></EmployeeCard> )
        })

    return(
        <div style={{textAlign:"center"}}>
            <h1>Employee List</h1>
            <table  className="table table-borderd" border={2}>
                <thead className="thead-dark">
                <tr>
                    <td>Employee ID</td>
                    <td>Employee Name</td>
                    <td>Employee Salary</td>
                   
                </tr></thead>
                <tbody>
                {renderEmployeeByTable()}
                </tbody>
            </table>
            <h1>Employee List By Component</h1>
            {renderEmployeeByComponent()}
        </div>
    );
}

export default EmployeeList;