import "./App.css";
import "bootstrap/dist/css/bootstrap.min.css";
import Header from "./components/Header";
import EmployeeList from "./components/EmployeeList";
import AddEmployee from "./components/AddEmployee";
import { useState } from "react";
function App() {
  // let Employees = [
  //   { id: 1, name: "Rohit", salary: 2000 },
  //   { id: 2, name: "Samir", salary: 9000 },
  //   { id: 3, name: "Mohit", salary: 2000 },
  // ];
const[Employees,setEmployees]=useState([
    { id: 1, name: "Rohit", salary: 2000 },
    { id: 2, name: "Samir", salary: 9000 },
    { id: 3, name: "Mohit", salary: 2000 },
  ]);
  const addEmployee=(ob)=>{
    let newEmployee=[...Employees,{...ob}];
    setEmployees(newEmployee)
  }

  return (
    <div>
      <Header></Header>
      <AddEmployee AddEmployeeHandler={addEmployee}></AddEmployee>
      <EmployeeList  Employee={Employees}/>
    </div>
  );
}

export default App;
