// src/components/Header.js
import React from 'react';

const Header = ({ loggedIn, onLogout }) => {
  return (
    <header>
      <h1>Workflow App</h1>
      {loggedIn && <button onClick={onLogout}>Logout</button>}
    </header>
  );
};

export default Header;
