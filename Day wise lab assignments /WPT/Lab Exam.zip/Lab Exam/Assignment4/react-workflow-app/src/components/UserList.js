// src/components/UserList.js
import React, { useState } from 'react';

const UserList = ({ users, onDelete, onEdit }) => {
  const [editMode, setEditMode] = useState(false);
  const [editedUser, setEditedUser] = useState({});
  const [editedIndex, setEditedIndex] = useState(null);

  const handleEdit = (index) => {
    setEditMode(true);
    setEditedUser(users[index]);
    setEditedIndex(index);
  };

  const handleSaveEdit = () => {
    onEdit(editedIndex, editedUser);
    setEditMode(false);
    setEditedUser({});
    setEditedIndex(null);
  };

  const handleCancelEdit = () => {
    setEditMode(false);
    setEditedUser({});
    setEditedIndex(null);
  };

  return (
    <div className="user-list">
      <h2>User Information</h2>
      <table>
        <thead>
          <tr>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Address</th>
            <th>Pin Code</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {users.map((user, index) => (
            <tr key={index}>
              <td>{user.firstName}</td>
              <td>{user.lastName}</td>
              <td>{user.address}</td>
              <td>{user.pinCode}</td>
              <td>
                <button onClick={() => handleEdit(index)}>Edit</button>
                <button onClick={() => onDelete(index)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {editMode && (
        <div className="edit-form">
          <h3>Edit User</h3>
          <label>
            First Name:
            <input
              type="text"
              value={editedUser.firstName}
              onChange={(e) =>
                setEditedUser({ ...editedUser, firstName: e.target.value })
              }
            />
          </label>
          <label>
            Last Name:
            <input
              type="text"
              value={editedUser.lastName}
              onChange={(e) =>
                setEditedUser({ ...editedUser, lastName: e.target.value })
              }
            />
          </label>
          <label>
            Address:
            <input
              type="text"
              value={editedUser.address}
              onChange={(e) =>
                setEditedUser({ ...editedUser, address: e.target.value })
              }
            />
          </label>
          <label>
            Pin Code:
            <input
              type="text"
              value={editedUser.pinCode}
              onChange={(e) =>
                setEditedUser({ ...editedUser, pinCode: e.target.value })
              }
            />
          </label>
          <button onClick={handleSaveEdit}>Save</button>
          <button onClick={handleCancelEdit}>Cancel</button>
        </div>
      )}
    </div>
  );
};

export default UserList;
