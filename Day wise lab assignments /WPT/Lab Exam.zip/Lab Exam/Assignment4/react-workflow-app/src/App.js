// src/App.js
import React, { useState } from 'react';
import Header from './components/Header';
import Login from './components/Login';
import AddUser from './components/AddUser';
import UserList from './components/UserList';
import './App.css';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [users, setUsers] = useState([]);

  const handleLogin = (username, password) => {
    // Perform authentication logic (for simplicity, just check for demo details)
    if (username === 'demo' && password === 'demo') {
      setLoggedIn(true);
    } else {
      alert('Invalid credentials');
    }
  };

  const handleLogout = () => {
    setLoggedIn(false);
  };

  const addUser = (user) => {
    setUsers([...users, user]);
  };

  const deleteUser = (index) => {
    const updatedUsers = [...users];
    updatedUsers.splice(index, 1);
    setUsers(updatedUsers);
  };

  const editUser = (index, updatedUser) => {
    const updatedUsers = [...users];
    updatedUsers[index] = updatedUser;
    setUsers(updatedUsers);
  };

  return (
    <div className="App">
      <Header loggedIn={loggedIn} onLogout={handleLogout} />
      {!loggedIn ? (
        <Login onLogin={handleLogin} />
      ) : (
        <>
          <AddUser onAddUser={addUser} />
          <UserList
            users={users}
            onDelete={deleteUser}
            onEdit={editUser}
          />
        </>
      )}
    </div>
  );
}

export default App;
