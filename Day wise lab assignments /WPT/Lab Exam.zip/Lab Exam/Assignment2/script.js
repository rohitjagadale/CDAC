$(document).ready(function () {
    var isUp = true;

    $(".toggle-btn").on("click", function () {
      if (isUp) {
        $(".go-top-btn").animate({ top: "-=400px" }, 500);
        $(".go-top-btn").text("Move Down");
      } else {
        $(".go-top-btn").animate({ top: "+=400px" }, 500);
        $(".go-top-btn").text("Move Up");
      }
      isUp = !isUp;
    });
  });