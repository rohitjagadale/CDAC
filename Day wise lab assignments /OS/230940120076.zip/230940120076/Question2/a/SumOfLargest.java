public class SumOfLargest {
    public static void main(String[] args) {
        // Initialize three integers
        int num1 = 5;
        int num2 = 8;
        int num3 = 3;

        // Find the largest number
        int largest = num1;
        if (num2 > largest) {
            largest = num2;
        }
        if (num3 > largest) {
            largest = num3;
        }

        // Display the sum of the largest number
        System.out.println("The sum of the largest number is: " + largest);
    }
}
