class EmptyTreeException extends Exception {
    EmptyTreeException () {
        
    }
}