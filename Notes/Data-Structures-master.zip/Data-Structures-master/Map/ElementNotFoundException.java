class ElementNotFoundException extends Exception {
    
}