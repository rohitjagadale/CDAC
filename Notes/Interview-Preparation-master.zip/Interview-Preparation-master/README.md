# InterviewPreparation

This repository gives the practice questions for preparing a software engineering Job

# Topics
### 1. [Data Structures Implementation](https://github.com/grv0908/InterviewPreparation/tree/master/DataStructuresImplementation)
### 2. [Arrays](https://github.com/grv0908/InterviewPreparation/tree/master/Arrays)
### 3. [Linked List](https://github.com/grv0908/InterviewPreparation/tree/master/LinkedList)
### 4. [Stack & Queues]()
### 5. [Tree](https://github.com/grv0908/InterviewPreparation/tree/master/Trees)
### 6. [Graphs](https://github.com/grv0908/InterviewPreparation/tree/master/Graphs)
### 7. [Dynamic Programming](https://github.com/grv0908/InterviewPreparation/tree/master/Dynamic%20Programming)
### 8. [Trie]()
### 9. [String]()
### 10. [Sorting]()
### 11. [Puzzles]()



