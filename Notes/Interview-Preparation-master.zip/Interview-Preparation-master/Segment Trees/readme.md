# Segment Tree

### Used when we need to store information about range or a segment
